package com.example.RoomReservationSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoomReservationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
